<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <table class="table ">
                <tr>
                    <th>name</th>
                    <th>email</th>
                    <th>invite</th>
                </tr>
                <?php foreach($data as $a): ?>
                    <tr>
                        <td><?php echo e($a->name); ?></td>
                        <td><?php echo e($a->email); ?></td>
                        <td>
                            <?php echo Form::open(array('url' => '/invite', 'method' => 'post')); ?>

                             <input type="hidden" name="reciverid" value="<?php echo e($a->id); ?>">
                            <input type="hidden" name="senderid" value="<?php echo e($aid); ?>">
                            <input type="hidden" name="wid" value="<?php echo e($wid); ?>">

                            <button type="submit" class="btn btn-success">invite</button>
                            <?php echo Form::close(); ?>



                            </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>