<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-lg-offset-3">
                <table class="table">
                    <tr>
                        <th>category</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    <?php foreach($data as $a): ?>
                        <tr>
                            <td>
                                <?php echo Form::open(array('route' => array('category.update', $a->id), 'method' => 'PATCH')); ?>

                                <input type="text" name="value" value="<?php echo e($a->value); ?>"></td>
                            <td>

                                <button type="submit" class="btn btn-success">Edit</button>
                                <input type="hidden" name="wid" value="<?php echo e($id); ?>">
                                <?php echo Form::close(); ?></td>
                            <td>
                                <?php echo Form::open(array('route' => array('category.destroy', $a->id), 'method' => 'DELETE')); ?>

                                <button type="submit" class="btn btn-danger">Delete</button>
                                <input type="hidden" name="wid" value="<?php echo e($id); ?>">
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>