<?php $__env->startSection('content'); ?>
        <div class="container">
        <div class="row">
            <div class="col-lg-3">

            </div>
            <div class="col-lg-6 ">
                <?php foreach($data as $a): ?>
                <div class="jumbotron">
                    <h1 class="h1-responsive"><?php echo e($a->name); ?></h1>

                    <hr class="m-y-2">
                    <p class="lead"><?php echo e($a->description); ?></p>
                    <p class="lead">
                        <a  href="<?php echo e(url('/wallet')); ?>/<?php echo e($a->id); ?>" class="btn btn-primary btn-lg" role="button">view</a>
                    </p>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="col-lg-3">
                <!--Panel-->
                <div class="card card-block" style="padding-right: 12px;">
                    <h4 class="card-title">Navigation</h4>
                    <a class="btn btn-primary btn-block" href="/home">Home page</a>
                    <a class="btn btn-success btn-block" href="/wallet/create">Create wallet</a>
                    <a class="btn btn-secondary btn-block" href="<?php echo e(url('/wallet/showmine')); ?>">Edit my wallets</a>


                </div>
                <!--/.Panel-->
            </div>
        </div>
            <div class="row">
                <div style="align-content: center" class="col-lg-6 col-lg-offset-3">
                    <?php echo e($data->links()); ?>

                </div>
            </div>


        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>