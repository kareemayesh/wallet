<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-lg-offset-3">
                <table class="table">
                    <tr>
                        <th>name</th>
                        <th>Delete</th>
                    </tr>
                    <?php foreach($data2 as $b): ?>
                    <?php foreach($data as $a): ?>

                        <tr>
                            <td><?php echo e($a->name); ?></td>
                            <td>
                                <?php echo Form::open(array('route' => array('delete_user'), 'method' => 'DELETE')); ?>

                                <button  onclick="return confirm('Are you sure you want to delete this item?');" type="submit" class="btn btn-danger ">Delete </button>
                                <input type="hidden" name="userid" value="<?php echo e($a->id); ?>">
                                <input type="hidden" name="wid" value="<?php echo e($b->wid); ?>" >
                                <?php echo Form::close(); ?>




                            </td>
                        </tr>
                            <?php endforeach; ?>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>